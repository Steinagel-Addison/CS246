package prove02;

/**
 *  Teleporters will teleport to other locations.
 * <p>
 * @author  Addison Steinagel
 * @version 1.0
 * @since   2018-5-4
 * @see Creature
 */
public interface Teleporter {

    /**
     * Teleports the {@link Creature}.
     */
    public void teleportCreature();

}
