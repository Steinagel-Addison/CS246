package prove02;

/**
 *  Spawners will spawn other creatures.
 * <p>
 * @author  Addison Steinagel
 * @version 1.0
 * @since   2018-5-4
 * @see Creature
 */
public interface Spawner {

    /**
     * Spawns the {@link Creature}.
     */
    public Creature spawnNewCreature();

}
