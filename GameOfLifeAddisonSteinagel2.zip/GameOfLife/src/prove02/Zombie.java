package prove02;

import java.awt.*;

/**
 * Zombies move from left to right, and attack. They are represented by blue squares.
 * <p>
 * @author  Addison Steinagel
 * @version 1.0
 * @since   2018-5-4
 * @see Creature
 */
public class Zombie extends Creature implements Movable, Aggressor {

    /**
     * Creates a zombie with 1 health
     */
    public Zombie() {
        _health = 1;
    }

    /**
     * If the creature we've encountered is not a plant, we'll eat it. Otherwise, we ignore it.
     * @param target The {@link Creature} we've encountered.
     */
    public void attack(Creature target) {
        // Zombies don't eat plants.  Give the creature
        // 10 damage if not a plant.  Increase health by 1
        if(target instanceof Zombie || target instanceof Animal  ||
                target instanceof Wolf || target instanceof Wizard) {
            target.takeDamage(10);
            _health++;
        }
    }

    /**
     * Move the zombie from left to right
     */
    public void move() {
        _location.x++;
    }

    @Override
    Shape getShape() {
        return Shape.Square;
    }

    @Override
    Color getColor() {
        return new Color(0, 72, 132);
    }

    @Override
    Boolean isAlive() {
        return _health > 0;
    }
}
