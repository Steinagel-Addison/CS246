package prove02;

import java.awt.*;
import java.util.Random;

/**
 * Wolves move around, chase prey and attack. They are represented by grey squares.
 * <p>
 * @author  Addison Steinagel
 * @version 1.0
 * @since   2018-5-4
 * @see Creature
 */
public class Wolf extends Creature implements Movable, Aware, Aggressor, Spawner {

    Random _rand;
    int _direction;
    Boolean _lockedOn;
    Boolean _justAte;

    /**
     * Creates a wolf with 1 health point.
     */
    public Wolf() {
        _rand = new Random();
        _health = 1;
        _lockedOn = false;
        _direction = 4;
        _justAte = false;
    }

    /**
     * Attacks the animals
     */
    @Override
    public void attack(Creature target) {
        // Wolves only eat other animals.  Give the creature
        // 5 damage if an animal.  Increase health by 1
        if(target instanceof Animal) {
            target.takeDamage(5);
            _health++;
            _justAte = true;
        }
    }

    /**
     * checks for any adjacent animals and changes direction
     */
    @Override
    public void senseNeighbors(Creature above, Creature below, Creature left, Creature right) {
        // starting with the direction the wolf is pointing,
        // and then above, it will search in a clockwise pattern
        switch (_direction) {
            case 0:
                if(right != null && right instanceof Animal) {
                    _lockedOn = true;
                    _direction = 0;
                } else if(above != null && above instanceof Animal) {
                    _lockedOn = true;
                    _direction = 2;
                } else if(below != null && below instanceof Animal) {
                    _lockedOn = true;
                    _direction = 3;
                } else if(left != null && left instanceof Animal) {
                    _lockedOn = true;
                    _direction = 1;
                } break;
            case 1:
                if(left != null && left instanceof Animal) {
                    _lockedOn = true;
                    _direction = 1;
                } else if(above != null && above instanceof Animal) {
                    _lockedOn = true;
                    _direction = 2;
                } else if(right != null && right instanceof Animal) {
                    _lockedOn = true;
                    _direction = 0;
                } else if(below != null && below instanceof Animal) {
                    _lockedOn = true;
                    _direction = 3;
                } break;
            case 2:
                if(above != null && above instanceof Animal) {
                    _lockedOn = true;
                    _direction = 2;
                } else if(right != null && right instanceof Animal) {
                    _lockedOn = true;
                    _direction = 0;
                } else if(below != null && below instanceof Animal) {
                    _lockedOn = true;
                    _direction = 3;
                } else if(left != null && left instanceof Animal) {
                    _lockedOn = true;
                    _direction = 1;
                } break;
            case 3:
                if(below != null && below instanceof Animal) {
                    _lockedOn = true;
                    _direction = 3;
                } else if(above != null && above instanceof Animal) {
                    _lockedOn = true;
                    _direction = 2;
                } else if(right != null && right instanceof Animal) {
                    _lockedOn = true;
                    _direction = 0;
                } else if(left != null && left instanceof Animal) {
                    _lockedOn = true;
                    _direction = 1;
                } break;
            default:
                break;
        }
    }

    @Override
    Shape getShape() {
        return Shape.Square;
    }

    @Override
    Color getColor() {
        return new Color(125, 125, 125);
    }

    @Override
    Boolean isAlive() {
        return _health > 0;
    }

    /**
     * Move the wolf randomly initially, and then in the direction of their prey
     */
    @Override
    public void move() {

        // If no creature is spotted yet, choose a
        // random direction each time move() is called.
        if (!_lockedOn) {
            switch (_rand.nextInt(4)) {
                case 0:
                    _location.x++;
                    _direction = 0;
                    break;
                case 1:
                    _location.x--;
                    _direction = 1;
                    break;
                case 2:
                    _location.y++;
                    _direction = 2;
                    break;
                case 3:
                    _location.y--;
                    _direction = 3;
                    break;
                default:
                    break;
            }
        } else {
            switch (_direction) {
                case 0:
                    _location.x++;
                    break;
                case 1:
                    _location.x--;
                    break;
                case 2:
                    _location.y++;
                    break;
                case 3:
                    _location.y--;
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Spawns other wolves after recently eating
     */
    @Override
    public Creature spawnNewCreature() {
        if (_justAte == true) {
            Wolf w = new Wolf();
            Point newLocation = new Point(this.getLocation().x - 1, this.getLocation().y);
            w.setLocation(newLocation);
            _justAte = false;
            return w;
        }
        else return null;
    }
}
