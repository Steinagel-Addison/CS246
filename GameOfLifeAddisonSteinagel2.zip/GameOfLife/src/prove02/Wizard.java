package prove02;

import java.awt.*;
import java.util.Random;

/**
 * Wizards move around and teleport. They are represented by black circles.
 * <p>
 * @author  Addison Steinagel
 * @version 1.0
 * @since   2018-5-4
 * @see Creature
 */
public class Wizard extends Creature implements Movable, Teleporter, Aware {

    Random _rand;
    int _direction;

    /**
     * Creates a wizard with 1 health point.
     */
    public Wizard() {
        _rand = new Random();
        _health = 1;
        _direction = 4;
    }

    @Override
    Shape getShape() {
        return Shape.Circle;
    }

    @Override
    Color getColor() {
        return new Color(0, 0, 0);
    }

    @Override
    Boolean isAlive() {
        return _health > 0;
    }

    /**
     * Move the wizard in a random direction.
     */
    @Override
    public void move() {
        // Choose a random direction each time move() is called.
        switch(_rand.nextInt(4)) {
            case 0:
                _location.x++;
                break;
            case 1:
                _location.x--;
                break;
            case 2:
                _location.y++;
                break;
            case 3:
                _location.y--;
                break;
            default:
                break;
        }
    }

    /**
     * Teleports the wizard 5 spaces away from any adjacent animal, wolf or zombie
     */
    @Override
    public void teleportCreature() {
        switch (_direction) {
            case 0:
                _location.x -= 5;
                _direction = 4;
                break;
            case 1:
                _location.x += 5;
                _direction = 4;
                break;
            case 2:
                _location.y -= 5;
                _direction = 4;
                break;
            case 3:
                _location.y += 5;
                _direction = 4;
                break;
            default:
                break;
        }
    }

    /**
     * checks for any adjacent wolf, zombie or animal
     */
    @Override
    public void senseNeighbors(Creature above, Creature below, Creature left, Creature right) {
        if (above != null && !(above instanceof Wizard || above instanceof Plant)) {
            _direction = 2;
        } else if (below != null && !(below instanceof Wizard || below instanceof Plant)) {
            _direction = 3;
        } else if (left != null && !(left instanceof Wizard || left instanceof Plant)) {
            _direction = 1;
        } else if (right != null && !(right instanceof Wizard || right instanceof Plant)) {
            _direction = 0;
        }
    }
}
